from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from extensions import db  # ✅ Import from extensions.py
from models import User, Expense  # ✅ Ensure these are imported
from forms import LoginForm, RegisterForm  # ✅ Ensure these are imported
from flask import session

app_routes = Blueprint('app_routes', __name__)

@app_routes.route('/')
def home():
    existing_user = User.query.first()
    if existing_user:
        return redirect(url_for('app_routes.login'))  # Redirect to login if a user exists
    else:
        return redirect(url_for('app_routes.register')) 

@app_routes.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user:
            flash('Email already registered!', 'danger')
            return redirect(url_for('app_routes.login'))
        
        # ✅ Store password as plain text (REMOVED HASHING)
        new_user = User(
            name=form.name.data,
            email=form.email.data,
            password=form.password.data  # ✅ Storing plain text password
        )
        db.session.add(new_user)
        db.session.commit()
        login_user(new_user)
        flash('Registration successful!', 'success')
        return redirect(url_for('app_routes.dashboard'))
    
    return render_template('register.html', form=form)

@app_routes.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and user.password == form.password.data:  # ✅ Since no hashing
            login_user(user)
            session['user_id'] = user.id  # ✅ Store user ID in session
            flash('Login successful!', 'success')
            return redirect(url_for('app_routes.dashboard'))
        else:
            flash('Invalid credentials', 'danger')
    return render_template('login.html', form=form)

@app_routes.route('/dashboard')
@login_required
def dashboard():
    expenses = Expense.query.filter_by(user_id=current_user.id).all() or []  # Ensure expenses is always a list
    return render_template('dashboard.html', expenses=expenses)

@app_routes.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logged out successfully!', 'success')
    return redirect(url_for('app_routes.login'))

@app_routes.route('/edit_expense/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_expense(id):
    expense = Expense.query.get_or_404(id)
    
    if request.method == 'POST':
        expense.name = request.form['name']
        expense.amount = request.form['amount']
        expense.date = request.form['date']
        db.session.commit()
        flash('Expense updated successfully!', 'success')
        return redirect(url_for('app_routes.dashboard'))

    return render_template('edit_expense.html', expense=expense)

@app_routes.route('/delete_expense/<int:id>', methods=['POST'])
@login_required
def delete_expense(id):
    expense = Expense.query.get_or_404(id)
    db.session.delete(expense)
    db.session.commit()
    flash('Expense deleted successfully!', 'success')
    return redirect(url_for('app_routes.dashboard'))

@app_routes.route('/add_expense', methods=['GET', 'POST'])
@login_required  # ✅ Ensures only logged-in users can access
def add_expense():
    if request.method == 'POST':
        name = request.form.get('name')
        amount = request.form.get('amount')
        date = request.form.get('date')

        if not name or not amount or not date:
            flash("All fields are required!", "danger")
            return redirect(url_for('app_routes.dashboard'))

        new_expense = Expense(name=name, amount=amount, date=date, user_id=current_user.id)  # ✅ Use `current_user.id`
        db.session.add(new_expense)
        db.session.commit()
        flash("Expense added successfully!", "success")
        return redirect(url_for('app_routes.dashboard'))

    return render_template('add_expense.html')
